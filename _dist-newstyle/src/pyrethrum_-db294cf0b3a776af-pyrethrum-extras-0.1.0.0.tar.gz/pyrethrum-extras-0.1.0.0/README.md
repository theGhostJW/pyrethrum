# PyrethrumExtras

A consolidation of external utiltiy libraries such as base-prelude and exceptions used plus a few of my own utility functions. Used in [pyrethrum](https://github.com/theGhostJW/pyrethrum)

