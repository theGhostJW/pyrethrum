
module TastyHUnitExtendedTest where

import           PyrethrumExtras.Test 

unit_chkEq = chkEq 1 1

unit_chkContains = chkContains "cool wor" "hello cool world"
